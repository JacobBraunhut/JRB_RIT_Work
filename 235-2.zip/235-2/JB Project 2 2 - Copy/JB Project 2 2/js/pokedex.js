const POKEAPI_POKEMON = "https://pokeapi.co/api/v2/pokemon/"; //Where we will directly get Pokemon from
const POKEAPI_REGION = "https://pokeapi.co/api/v2/generation/"; //The region where the Pokemon can be found. Originally used to be Generation
const POKEAPI_TYPE = "https://pokeapi.co/api/v2/type/"; //The type attribute that the Pokemon has.

let displayTerm = "";

function init(){
    document.querySelector("#nameButton").onclick = nameButtonClicked;
    document.querySelector("#numberButton").onclick = numberButtonClicked;
    document.querySelector("#typeButton").onclick = typeButtonClicked;
}
window.onload = init;

//window.onload = (e) => {document.querySelector("#nameButton").onclick = nameButtonClicked};
//window.onload = (e) => {document.querySelector("#numberButton").onclick = numberButtonClicked};
//window.onload = (e) => {document.querySelector("#typeButton").onclick = typeButtonClicked};


function nameButtonClicked(){
    console.log("button being pushed");
    
    // 3
    let url = POKEAPI_POKEMON;

    // 4
    let term = document.querySelector("#searchterm").value;
    displayTerm = term;

    // 5
    term = term.trim();

    // 6
    term = encodeURIComponent(term);

    // 7
    if(term.length < 1) return;

    // 8
    url += term;
    url += "/";
    
    // 12 Request data!
    getData(url);

}

function numberButtonClicked(){
    console.log("button being pushed");
    
    // 3
    let url = POKEAPI_POKEMON;

    // 4
    let term = document.querySelector("#numberterm").value;
    displayTerm = term;

    // 5
    term = term.trim();

    // 6
    term = encodeURIComponent(term);

    // 7
    if(term.length < 1) return;

    // 8
    url += term;
    url += "/";
    
    // 12 Request data!
    getData(url);

}

function typeButtonClicked(){
    console.log("button being pushed");
    
    // 3
    let url = POKEAPI_TYPE;

    // 4
    let term = document.querySelector("#types1").value;
    displayTerm = term;

    // 5
    term = term.trim();

    // 6
    term = encodeURIComponent(term);

    // 7
    if(term.length < 1) return;

    // 8
    url += term;
    url += "/";
    
    // 12 Request data!
    getData(url);

}

function regionButtonClicked(){
    console.log("button being pushed");
    
    // 3
    let url = POKEAPI_REGION;

    // 4
    let term = document.querySelector("#region").value;
    displayTerm = term;

    // 5
    term = term.trim();

    // 6
    term = encodeURIComponent(term);

    // 7
    if(term.length < 1) return;

    // 8
    url += term;
    url += "/";
    
    // 12 Request data!
    getData(url);

}

function getData(url){
    // 1
    let xhr = new XMLHttpRequest();

    // 2
    xhr.onload = dataLoaded;

    // 3
    xhr.onerror = dataError;

    // 4
    xhr.open("GET", url);
    xhr.send();
}

// Callback Functions

function dataLoaded(e){
    // 5
    let xhr = e.target;

    // 7
    let obj = JSON.parse(xhr.responseText);

    // 8
    if(!obj.name || obj.name.length == 0){
        document.querySelector("#status").innerHTML = "<b>No results found for '" + displayTerm + "'</b>";
        return; //bail
    }

    // 9
    let result = obj;
    let bigString = "";
        
        // 13
        let line = `<div class='result'><img src="${result["sprites"]["front_default"]}}"  alt=""></div>`;

    // 16
    document.querySelector("#content").innerHTML = line

    // 17
    document.querySelector("#status").innerHTML = "<b>Success!</b><p><i>Here's that Pokemon!</i></p>";
}

function dataError(e){
    console.log("Whoops, an error occurred!");
}