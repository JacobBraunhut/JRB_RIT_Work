class Ship extends PIXI.Sprite {
    constructor(x = 0, y = 0){
        super(app.loader.resources["images/spaceship.png"].texture);
        this.anchor.set(.5, .5);
        this.scale.set(0.1);
        this.x = x;
        this.y = y;
    }
}

class Circle extends PIXI.Graphics{
    constructor(radius, color = 0xFF0000, x=0, y=0){
        super();
        this.beginFill(color);
        this.drawCircle(0,0,radius);
        this.endFill();
        this.x = x;
        this.y = y;
        this.radius = radius;
        //variables
        this.fwd = getRandomUnitVector();
        this.speed = 50;
        this.isAlive = true;
    }

    move(dt = 1/60){
        this.x += this.fwd.x * this.speed * dt;
        this.y += this.fwd.y * this.speed * dt;
    }

    reflectX(){
        this.fwd.x *= -1;
    }

    reflectY(){
        this.fwd.y *= -1;
    }
}

class Bullet extends PIXI.Graphics{
    constructor(color = 0xFF0000, x=0, y=0){
        super();
        this.beginFill(color);
        this.drawRect(-2, -3, 4, 6);
        this.endFill();
        this.x = x;
        this.y = y;
        //variables
        this.fwd = {x:0, y:-1};
        this.speed = 400;
        this.isAlive = true;
        Object.seal(this);
    }

    move(dt=1/60){
        this.x += this.fwd.x * this.speed * dt;
        this.y += this.fwd.y * this.speed * dt;
    }
}

class Bomb extends PIXI.Sprite{
    constructor(x = 0, y = 0){
        super(app.loader.resources["images/Bomb.png"].texture);
        this.scale.set(0.5);
        this.x = x;
        this.y = y;
        //variables
        this.fwd = {x:0, y:-1};
        this.speed = 50;
        this.isAlive = true;
    }

    move(dt=1/60){
        this.x += this.fwd.x * this.speed * dt;
        this.y += this.fwd.y * this.speed * dt;
    }
}

//Unused Mechanic
class HitBox extends PIXI.Sprite{
    constructor(x = 0, y = 0){
        super(app.loader.resources["images/BombExplosion.png"].texture);
        this.scale.set(0.35);
        this.x = x;
        this.y = y;
        //variables
        this.fwd = {x:0, y:0};
        this.speed = 50;
        this.isAlive = true;
    }

    move(dt=1/60){
        this.x += this.fwd.x * this.speed * dt;
        this.y += this.fwd.y * this.speed * dt;
    }
}

class Health extends PIXI.Sprite{
    constructor(x = 0, y = 0){
        super(app.loader.resources["images/HealthPickUp.png"].texture);
        this.scale.set(0.5);
        this.x = x;
        this.y = y;
        //variables
        this.fwd = {x:0, y:1};
        this.speed = 50;
        this.isAlive = true;
    }

    move(dt = 1/60){
        this.x += this.fwd.x * this.speed * dt;
        this.y += this.fwd.y * this.speed * dt;
    }

    reflectX(){
        this.fwd.x *= -1;
    }

    reflectY(){
        this.fwd.y *= -1;
    }
}