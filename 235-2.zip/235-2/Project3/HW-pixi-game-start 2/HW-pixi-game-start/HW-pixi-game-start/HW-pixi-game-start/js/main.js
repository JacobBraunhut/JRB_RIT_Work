// We will use `strict mode`, which helps us by having the browser catch many common JS mistakes
// https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Strict_mode
"use strict";
const app = new PIXI.Application({
    width: 600,
    height: 600
});
document.body.appendChild(app.view);

// constants
const sceneWidth = app.view.width;
const sceneHeight = app.view.height;	

// pre-load the images
app.loader
    .add([
        "images/spaceship.png",
        "images/explosions.png",
        "images/Bomb.png",
        "images/HealthPickUp.png",
        "images/BombExplosion.png"
    ]);
app.loader
    .add("backbackbackBg", "images/TinyRedStars.png")
    .add("backbackBg", "images/TinyGreenStars.png")
    .add("backBg", "images/SmallBlueStars.png")
    .add("frontBg", "images/StarsSmall.png");
app.loader.onProgress.add(e => { console.log(`progress=${e.progress}`) });
app.loader.onComplete.add(setup);
app.loader.load();

// aliases
let stage;

// game variables
let startScene;
let gameScene,ship,scoreLabel,endScoreLabel,lifeLabel,levelLabel,shootSound,hitSound,fireballSound,collectingSound,explosionSound;
let gameOverScene;

let circles = [];
let bullets = [];
let aliens = [];
let explosions = [];
let pickups = [];
let bombs = [];
let explosionTextures;
let score = 0;
let life = 100;
let levelNum = 1;
let paused = true;
let bgBackBackBack;
let bgBackBack;
let bgBack;
let bgFront;
let bgY = 0;
let bgSpeed = 1;
let keys = {};

function setup() {
	stage = app.stage;
	// #1 - Create the `start` scene
    startScene = new PIXI.Container();
    stage.addChild(startScene);
	
	// #2 - Create the main `game` scene and make it invisible
    gameScene = new PIXI.Container();
    gameScene.visible = false;
    stage.addChild(gameScene);


	// #3 - Create the `gameOver` scene and make it invisible
    gameOverScene = new PIXI.Container();
    gameOverScene.visible = false;
    stage.addChild(gameOverScene);
	
	// #4 - Create labels for all 3 scenes
    createLabelsAndButtons();
	
	// #5 - Create ship
    ship = new Ship();
    gameScene.addChild(ship);
	
	// #6 - Load Sounds
    shootSound = new Howl({
	    src: ['sounds/Shoot.mp3']
    });

    hitSound = new Howl({
	    src: ['sounds/hit.mp3']
    });

    fireballSound = new Howl({
	    src: ['sounds/fireball.mp3']
    });

    collectingSound = new Howl({
        src: ['sounds/Collecting.mp3']
    });

    explosionSound = new Howl({
        src: ['sounds/ExplosionScratch.mp3']
    });
	
	// #7 - Load sprite sheet
    explosionTextures = loadSpriteSheet();

        //background
        bgBackBackBack = createBg(app.loader.resources["backbackbackBg"].texture);
        bgBackBack = createBg(app.loader.resources["backbackBg"].texture);
        bgBack = createBg(app.loader.resources["backBg"].texture);
        bgFront = createBg(app.loader.resources["frontBg"].texture);
		
	// #8 - Start update loop
    app.ticker.add(gameLoop);

    // #10 - Add event Listeners!
    window.addEventListener("keydown", keysDown);
    window.addEventListener("keyup", keysUp);
	
	// Now our `startScene` is visible
	// Clicking the button calls startGame()
}

function createLabelsAndButtons()
{
    let buttonStyle = new PIXI.TextStyle({
        fill: 0xFF0000,
        fontSize: 48,
        fontFamily: "Verdana"
    });

    //1 set up start scene
    let startLabel1 = new PIXI.Text("Circle Blast Redux!");
    startLabel1.style = new PIXI.TextStyle({
        fill: 0xFFFFFF,
        fontSize: 96,
        fontFamily: "Verdana",
        stroke: 0xFF0000,
        strokeThickness: 6
    });
    startLabel1.x = 50;
    startLabel1.y = 120;
    startScene.addChild(startLabel1);

    let startLabel2 = new PIXI.Text("WASD and Arrow Keys to move, SpaceBar to shoot, Z to throw Bomb");
    startLabel2.style = new PIXI.TextStyle({
        fill: 0xFFFFFF,
        fontSize: 32,
        fontFamily: "Verdana",
        fontStyle: "italics",
        stroke: 0xFF0000,
        strokeThickness: 6
    });
    startLabel2.x = 185;
    startLabel2.y = 300;
    startScene.addChild(startLabel2);

    let startButton = new PIXI.Text("Press Start To Play");
    startButton.style = buttonStyle;
    startButton.x = 80;
    startButton.y = sceneHeight - 100;
    startButton.interactive = true;
    startButton.buttonMode = true;
    startButton.on("pointerup", startGame);
    startScene.addChild(startButton);

    //2 set up Game Scene
    let textStyle = new PIXI.TextStyle({
        fill: 0xFFFFFF,
        fontSize: 18,
        fontFamily: "Verdana",
        stroke: 0xFF0000,
        strokeThickness: 4
    });

    scoreLabel = new PIXI.Text();
    scoreLabel.style = textStyle;
    scoreLabel.x = 5;
    scoreLabel.y = 5;
    gameScene.addChild(scoreLabel);
    increaseScoreBy(0);

    lifeLabel = new PIXI.Text();
    lifeLabel.style = textStyle;
    lifeLabel.x = 5;
    lifeLabel.y = 26;
    gameScene.addChild(lifeLabel);
    decreaseLifeBy(0);

    levelLabel = new PIXI.Text();
    levelLabel.style = textStyle;
    levelLabel.x = 5;
    levelLabel.y = 47;
    gameScene.addChild(levelLabel);
    increaseLevelBy(0);

    // 3 - set up `gameOverScene`
// 3A - make game over text
let gameOverText = new PIXI.Text("Game Over!\n        :-O");
textStyle = new PIXI.TextStyle({
	fill: 0xFFFFFF,
	fontSize: 64,
	fontFamily: "Futura",
	stroke: 0xFF0000,
	strokeThickness: 6
});

gameOverText.style = textStyle;
gameOverText.x = 100;
gameOverText.y = sceneHeight/2 - 160;
gameOverScene.addChild(gameOverText);

// 3B - make "play again?" button
let playAgainButton = new PIXI.Text("Play Again?");
playAgainButton.style = buttonStyle;
playAgainButton.x = 150;
playAgainButton.y = sceneHeight - 100;
playAgainButton.interactive = true;
playAgainButton.buttonMode = true;
playAgainButton.on("pointerup",startGame); // startGame is a function reference
playAgainButton.on('pointerover',e=>e.target.alpha = 0.7); // concise arrow function with no brackets
playAgainButton.on('pointerout',e=>e.currentTarget.alpha = 1.0); // ditto
gameOverScene.addChild(playAgainButton);
}

function startGame()
{
    startScene.visible = false;
    gameOverScene.visible = false;
    gameScene.visible = true;
    score = 0;
    life = 100;
    increaseScoreBy(0);
    decreaseLifeBy(0);
    increaseLevelBy(0);
    ship.x = 300;
    ship.y = 550;
    loadLevel();
}

function increaseScoreBy(value){
    score += value;
    scoreLabel.text = `Score ${score}`;
}

function decreaseLifeBy(value){
    life -= value;
    life = parseInt(life);
    lifeLabel.text = `Life     ${life}`;
}

//Level
function increaseLevelBy(value){
    levelNum += value;
    levelLabel.text = `Level    ${levelNum}`;
}

//Receiving health
function increaseLifeBy(value){
    life += value;
    life = parseInt(life);
    lifeLabel.text = `Life     ${life}`;
}

function gameLoop(){
	if (paused) return; // keep this commented out for now
	
	// #1 - Calculate "delta time"
    let dt = 1/app.ticker.FPS;
    if (dt > 1/12) dt=1/12;
	
    // #2 - Move Ship
    if(keys["87"] || keys["38"])
    {
        ship.y -= 3;
    }
    if(keys["83"] || keys["40"])
    {
        ship.y += 3;
    }
    if(keys["65"] || keys["37"])
    {
        ship.x -= 3;
    }
    if(keys["68"] || keys["39"])
    {
        ship.x += 3;
    }
    if(keys["32"])
    {
        fireBullet();
        keys["32"] = false;
    }
    if(keys["90"])
    {
        fireBomb();
        keys["90"] = false;
    }
	
	// #3 - Move Circles
    for(let c of circles){
        c.move(dt);
        if(c.x <= c.radius ||  c.x >= sceneWidth - c.radius){
            c.reflectX();
            c.move(dt);
        }
        if(c.y <= c.radius ||  c.y >= sceneHeight - c.radius){
            c.reflectY();
            c.move(dt);
        }
    }
	
	
	// #4 - Move Bullets
	for (let b of bullets){
		b.move(dt);
	}

    // #4 - Move Bombs
	for (let p of bombs){
		p.move(dt);
	}


    //#4 - Move Health Items
    for (let h of pickups){
        h.move(dt);
    }

	
	// #5 - Check for Collisions
    for(let c of circles){
        // leave space below empty
        for(let b of bullets){
            if(rectsIntersect(c,b)){
                fireballSound.play();
                itemDrop(c.x, c.y);
                createExplosion(c.x,c.y,64,64);
                gameScene.removeChild(c);
                c.isAlive = false;
                gameScene.removeChild(b);
                b.isAlive = false;
                increaseScoreBy(1);
            }

            if (b.y < -10) b.isAlive = false;
        }

        for(let p of bombs){
            if(rectsIntersect(c,p)){
                explosionSound.play();
                itemDrop(c.x, c.y);
                createExplosion(c.x,c.y,64,64);
                gameScene.removeChild(c);
                c.isAlive = false;
                gameScene.removeChild(p);
                p.isAlive = false;
                increaseScoreBy(1);
            }
            if (p.y < -60) p.isAlive = false;
        }
        // leave space above empty

        if(c.isAlive && rectsIntersect(c, ship)){
            hitSound.play();
            gameScene.removeChild(c);
            c.isAlive = false;
            decreaseLifeBy(20);
        }
    }

    for(let h of pickups)
    {
        if(h.isAlive && rectsIntersect(h, ship))
        {
            collectingSound.play();
            gameScene.removeChild(h);
            h.isAlive = false;
            increaseLifeBy(20);
        }
    }
	
	
	// #6 - Now do some clean up

    bullets = bullets.filter(b=>b.isAlive);

    circles = circles.filter(c=>c.isAlive);

    bombs = bombs.filter(p=>p.isAlive);

    explosions = explosions.filter(e=>e.playing);

    pickups = pickups.filter(h=>h.isAlive);


    //Updating the background
    updateBg();
	
	
	// #7 - Is game over?
    if (life <= 0){
	    end();
	    return; // return here so we skip #8 below
    }
	
	
	// #8 - Load next level
    if (circles.length == 0){
	    levelNum ++;
	    loadLevel();
        levelUp();
    }
}

function createCircles(numCircles){
    for(let i = 0; i < numCircles; i++)
    {
        let c = new Circle(10, 0xFFFF00);
        c.x = Math.random() * (sceneWidth - 50) + 25;
        c.y = Math.random() * (sceneHeight - 400) + 25;
        circles.push(c);
        gameScene.addChild(c);
    }
}

function loadLevel(){
	createCircles(levelNum * 5);
	paused = false;
}

function levelUp(){
    ship.x = ship.x * 1.1;
    ship.y = ship.y * 1.1;
}

function end(){
    paused = true;

    circles.forEach(c=>gameScene.removeChild(c));
    circles = [];

    bullets.forEach(b=>gameScene.removeChild(b));
    bullets = [];

    explosions.forEach(e=>gameScene.removeChild(e));
    explosions = [];

    gameOverScene.visible = true;
    gameScene.visible = false;
}

function fireBullet(e){
    if (paused) return;

    let b = new Bullet(0xFFFFFF,ship.x,ship.y);
    bullets.push(b);
    gameScene.addChild(b);
    shootSound.play();
}

function loadSpriteSheet(){
    //the 16 animation frames in each row are 64x64 pixels
    //we are using the second row
    //http://pixijs.download/dev/docs/PIXI.BaseTexture.html
    let spriteSheet = PIXI.BaseTexture.from("images/explosions.png");
    let width = 64;
    let height = 64;
    let numFrames = 16;
    let textures = [];
    for(let i = 0; i < numFrames; i++){
        //http://pixijs.download/dev/docs/PIXI.Texture.html
        let frame = new PIXI.Texture(spriteSheet, new PIXI.Rectangle(i * width, 64, width, height));
        textures.push(frame);
    }
    return textures;
}

function createExplosion(x, y, frameWidth, frameHeight){
    //http://pixijs.download/release/docs/PIXI.AnimatedSprite.html
    let w2 = frameWidth/2;
    let h2 = frameHeight/2;
    let expl = new PIXI.AnimatedSprite(explosionTextures);
    expl.x = x - w2;
    expl.y = y - h2;
    expl.animationSpeed = 1/7;
    expl.loop = false;
    expl.onComplete = e => gameScene.removeChild(expl);
    explosions.push(expl);
    gameScene.addChild(expl);
    expl.play();
}

function createBg(texture){
    let tiling = new PIXI.TilingSprite(texture, 600, 600);
    tiling.position.set(-50,0);
    app.stage.addChild(tiling);

    return tiling;
}

function updateBg(){
    bgY = (bgY + bgSpeed);
    bgFront.tilePosition.y = bgY ;
    bgBack.tilePosition.y = bgY * 2;
    bgBackBack.tilePosition.y = bgY * 3;
    bgBackBackBack.tilePosition.y = bgY * 4;
}

function keysDown(e)
{
    keys[e.keyCode] = true;
}

function keysUp(e)
{
    keys[e.keyCode] = false;
}

//Fires a Bomb
function fireBomb(e){
    if (paused) return;

    let p = new Bomb(ship.x, ship.y);
    bombs.push(p);
    gameScene.addChild(p);
    shootSound.play();
}

//Drops a Health Pickup
function itemDrop(x, y){
    let ranNum = getRandomInt(10);
    if(ranNum == 1)
    {
        let h = new Health(x, y);
        pickups.push(h);
        gameScene.addChild(h);
    }
}