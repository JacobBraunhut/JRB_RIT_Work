﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//Name: Jacob Braunhut
//Goal: To make a game of Triangle Solitare without clear instructions.
//Project: HW5 - The Last Homework
//Date: 7/31/2021
namespace IGMEJBHW5
{
    class JumpGraph
    {
        //attribute
        Dictionary<int, JumpList> possibleMoves;

        //constructor
        public JumpGraph()
        {
            possibleMoves = new Dictionary<int, JumpList>();
            //All of the possible moves
            Add(0, new Jump(3, 0, 1));
            Add(0, new Jump(5, 0, 2));
            Add(1, new Jump(6, 1, 3));
            Add(1, new Jump(8, 1, 4));
            Add(2, new Jump(7, 2, 4));
            Add(2, new Jump(9, 2, 5));
            Add(3, new Jump(0, 3, 1));
            Add(3, new Jump(5, 3, 4));
            Add(3, new Jump(10, 3, 6));
            Add(3, new Jump(12, 3, 7));
            Add(4, new Jump(11, 4, 7));
            Add(4, new Jump(13, 4, 8));
            Add(5, new Jump(0, 5, 2));
            Add(5, new Jump(3, 5, 4));
            Add(5, new Jump(12, 5, 8));
            Add(5, new Jump(14, 5, 9));
            Add(6, new Jump(1, 6, 3));
            Add(6, new Jump(8, 6, 7));
            Add(7, new Jump(2, 7, 4));
            Add(7, new Jump(9, 7, 8));
            Add(8, new Jump(1, 8, 4));
            Add(8, new Jump(6, 8, 7));
            Add(9, new Jump(2, 9, 5));
            Add(9, new Jump(7, 9, 8));
            Add(10, new Jump(3, 10, 6));
            Add(10, new Jump(12, 10, 11));
            Add(11, new Jump(4, 11, 7));
            Add(11, new Jump(13, 11, 12));
            Add(12, new Jump(3, 12, 7));
            Add(12, new Jump(5, 12, 8));
            Add(12, new Jump(10, 12, 11));
            Add(12, new Jump(14, 12, 13));
            Add(13, new Jump(4, 13, 8));
            Add(13, new Jump(11, 13, 12));
            Add(14, new Jump(5, 14, 9));
            Add(14, new Jump(12, 14, 13));
        }

        //Adds a move to the list
        public void Add(int pos, Jump jump)
        {
            if (possibleMoves.ContainsKey(pos) == false)
            {
                possibleMoves.Add(pos, new JumpList());
            }
            possibleMoves[pos].Add(jump);
        }

        //Gets the moves from the list
        public JumpList GetMoves(int pos)
        {
            if (possibleMoves.ContainsKey(pos))
            {
                return possibleMoves[pos];
            }
            return null;
        }
    }
}
