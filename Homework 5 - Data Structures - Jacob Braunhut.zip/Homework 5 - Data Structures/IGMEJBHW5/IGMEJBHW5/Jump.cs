﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//Name: Jacob Braunhut
//Goal: To make a game of Triangle Solitare without clear instructions.
//Project: HW5 - The Last Homework
//Date: 7/31/2021
namespace IGMEJBHW5
{
    class Jump
    {
        //attributes
        public int from;
        public int to;
        public int over;

        public Jump next;

        //properties
        public int From
        {
            get { return from; }
        }
        public int To
        {
            get { return to; }
        }
        public int Over
        {
            get { return over; }
        }

        public Jump Next
        {
            get { return next; }
            set { next = value; }
        }

        //Constructor that calls a jump
        public Jump(Jump jump)
        {
            this.from = jump.From;
            this.to = jump.To;
            this.over = jump.Over;
        }

        //Constructor that creats a Jump with from, to, and over variables
        public Jump(int from, int to, int over)
        {
            this.from = from;
            this.to = to;
            this.over = over;
            next = null;
        }

        //ToString method prints the moves
        public override string ToString()
        {
            string str = string.Format("From {0} to {1} over {2}", from, to, over);
            return str;
        }
    }
}
