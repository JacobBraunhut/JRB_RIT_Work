﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
//Name: Jacob Braunhut
//Goal: To make a game of Triangle Solitare without clear instructions.
//Project: HW5 - The Last Homework
//Date: 7/31/2021
namespace IGMEJBHW5
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
