﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//Name: Jacob Braunhut
//Goal: To make a game of Triangle Solitare without clear instructions.
//Project: HW5 - The Last Homework
//Date: 7/31/2021
namespace IGMEJBHW5
{
    class Vertex
    {
        //attributes
        private int peg;
        private bool visited;

        //properties
        public int Peg
        {
            get { return peg; }
        }

        public bool Visited
        {
            get { return visited; }
            set { visited = value; }
        }

        //constructor takes the number of spaces
        public Vertex(int peg)
        {
            this.peg = peg;
            visited = false;
        }

        //ToString Function
        public override string ToString()
        {
            return base.ToString();
        }
    }
}
