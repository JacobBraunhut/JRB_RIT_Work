﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IGMEJBHW5
{
    public partial class Form1 : Form
    {
        //constant number of pegs
        const int pegNum = 15;
        public Form1()
        {
            InitializeComponent();
        }

        private void StartButton_Click(object sender, EventArgs e)
        {
            //Creates a new gameboard
            GameBoard board = new GameBoard(pegNum, 0);
            //Loops through the gameboard and plays the game
            for(int i = 1; i < pegNum; i++)
            {
                //Creates a new stack
                JumpList jumpStack = new JumpList();
                //Plays the game
                if(board.Play(jumpStack))
                {
                    ResultsBox.Text += "Moves For " + i + "\n";
                    jumpStack = jumpStack.ReverseStack();
                    //Checks to see if the entry in the list is empty
                    while(jumpStack.IsEmpty() == false)
                    {
                        ResultsBox.Text += jumpStack.Pop().ToString() + "\n";
                    }
                }
                //resets the board
                board.ResetBoard(pegNum, i);
            }
        }


        private void ResultsBox_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
