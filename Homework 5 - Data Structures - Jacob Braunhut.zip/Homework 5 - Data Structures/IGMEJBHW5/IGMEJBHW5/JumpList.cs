﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//Name: Jacob Braunhut
//Goal: To make a game of Triangle Solitare without clear instructions.
//Project: HW5 - The Last Homework
//Date: 7/31/2021
namespace IGMEJBHW5
{
    class JumpList
    {
        //attribute
        private Jump head;

        //property
        public Jump Front
        {
            get { return head; }
        }

        //Reverses the list and prints the moves in correct order
        public JumpList ReverseStack()
        {
            JumpList stack = new JumpList();
            while (IsEmpty() == false)
            {
                stack.Push(Pop());
            }
            return stack;
        }

        //Adds a jump to the jump list
        public void Add(Jump jump)
        {
            if (head == null)
            {
                head = jump;
                return;
            }

            Jump prev = head;
            Jump curr = head.Next;

            while (curr != null)
            {
                prev = curr;
                curr = curr.Next;
            }
            prev.Next = jump;
        }

        //Pushes a jump to the JumpList
        public void Push(Jump jump)
        {
            if (jump != null)
            {
                jump.Next = head;
                head = jump;
            }
        }

        //Removes a jump from the jumpList
        public Jump Pop()
        {
            Jump prev = head;
            if (head != null)
            {
                head = head.Next;
            }
            return prev;
        }

        //Checks to see if the Jump is Empty
        public bool IsEmpty()
        {
            if (head == null)
            {
                return true;
            }
            return false;
        }
    }
}
