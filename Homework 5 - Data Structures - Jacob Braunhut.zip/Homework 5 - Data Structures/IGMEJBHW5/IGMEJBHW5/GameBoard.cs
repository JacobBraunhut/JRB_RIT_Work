﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//Name: Jacob Braunhut
//Goal: To make a game of Triangle Solitare without clear instructions.
//Project: HW5 - The Last Homework
//Date: 7/31/2021
namespace IGMEJBHW5
{
    class GameBoard
    {
        //attributes
        List<bool> board;
        List<Vertex> empties;
        Dictionary<int, Vertex> verticies;
        JumpGraph possibleMoves;

        //constructor
        public GameBoard(int pegs, int hole)
        {
            possibleMoves = new JumpGraph();
            verticies = new Dictionary<int, Vertex>();
            ResetVerticies(pegs);
            ResetBoard(pegs, hole);
        }

        //Resets the board and sets the gameboard again
        public void ResetBoard(int pegs, int hole)
        {
            board = new List<bool>(pegs);
            empties = new List<Vertex>();

            for (int i = 0; i < board.Capacity; i++)
            {
                board.Add(true);
            }
            Empty(hole);
        }

        //Resets the verticies in the dictionary
        public void ResetVerticies(int pegs)
        {
            for (int i = 0; i < pegs; i++)
            {
                verticies.Add(i, new Vertex(i));
            }
        }

        //Gets all possible moves that can be made
        public JumpList GetAllMoves()
        {
            JumpList returnList = new JumpList();
            foreach (Vertex v in empties)
            {
                Jump temp = possibleMoves.GetMoves(v.Peg).Front;
                while (temp != null)
                {
                    if (IsEmpty(temp.From) == false && IsEmpty(temp.Over) == false && IsEmpty(temp.To))
                    {
                        returnList.Add(new Jump(temp));
                    }
                    temp = temp.Next;
                }
            }
            return returnList;
        }

        //Empties a position on the board
        public void Empty(int pos)
        {
            board[pos] = false;
            if (empties.Contains(verticies[pos]) == false)
            {
                empties.Add(verticies[pos]);
            }
        }

        //Fills a position on the board
        public void Fill(int pos)
        {
            board[pos] = true;
            if (empties.Contains(verticies[pos]) == true)
            {
                empties.Remove(verticies[pos]);
            }
        }

        //Moves the peg to the new position
        public void Move(Jump jump)
        {
            Empty(jump.From);
            Fill(jump.To);
            Empty(jump.Over);
        }

        //Undoes the move previously made
        public void UndoMove(Jump jump)
        {
            Fill(jump.From);
            Empty(jump.To);
            Fill(jump.Over);
        }

        //Checks to see if the game is over
        public bool IsGameOver()
        {
            if (empties.Count == board.Count - 1)
            {
                return true;
            }
            return false;
        }

        //Checks to see if a space is empty
        public bool IsEmpty(int pos)
        {
            if (board[pos] == false)
            {
                return true;
            }
            return false;
        }

        //The function that plays the game
        public bool Play(JumpList jumpStack)
        {
            //Checks to see if the game is over first
            if (IsGameOver())
            {
                return true;
            }

            //A current jump checks all the possible moves
            Jump curr = GetAllMoves().Front;
            //loop that occurs while the current jump is not null
            while (curr != null)
            {
                //checks to see if the space your jumping from and over isn't empty.
                if (IsEmpty(curr.From) == false && IsEmpty(curr.Over) == false)
                {
                    Move(curr);
                    jumpStack.Push(new Jump(curr));
                    if (Play(jumpStack) == true)
                    {
                        return true;
                    }
                    else
                    {
                        UndoMove(jumpStack.Pop());
                    }
                }
                curr = curr.Next;//Moves to the next node in the list
            }
            return IsGameOver();
        }
    }
}
